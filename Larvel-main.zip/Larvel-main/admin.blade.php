@extends('layouts.adminMain')
@section('content')
<div class="content-wrapper">
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <h1>main Admin panel Page</h1>
                    <hr>
                </div>
            </div>
        </div>
    </section>
</div>